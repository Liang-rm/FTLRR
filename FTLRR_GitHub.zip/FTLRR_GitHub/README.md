# FTLRR / NFTLRR: MATLAB reference code

Reference implementation of **Factorized Tensor Low-Rank Representation (FTLRR)** and its
affinely normalized extension **NFTLRR**, for subspace clustering of tensor-valued samples
(lateral slices `X(:,j,:)`), as described in

> R. Liang and C. Wang, *Tensor Subspace Clustering via Normalized Factorized Low-Rank
> Representation*, Knowledge-Based Systems (manuscript KNOSYS-D-26-21897).

`FTLRR` fits the coefficient tensor of a tensor low-rank representation by the t-product of
two thin factors of prescribed inner width `m`, instead of shrinking the coefficient with a
tensor nuclear norm. `NFTLRR` adds the affine constraint `G * Z = G`, which makes the
reconstruction residual invariant under a common translation of the observations and the
dictionary, and is solved through an exact augmented reduction that preserves both the
reconstruction and the affine constraint.

## Repository layout

The repository contains two independent implementations. The MATLAB package reproduces
the face-table results of Sections 6.1–6.5; the Python package reproduces the numerical
diagnostics and additional experiments of Section 6.6.

| Folder | Contents |
|---|---|
| `src/`, `run_face.m`, `examples/` | MATLAB implementation of FTLRR and NFTLRR |
| `python/` | Python reference implementation and the COIL experiment |

## Results on EYaleB

Ten clustering runs of the deterministic fit, `m = 28`, TRPCA dictionary with the published
options (`mu = 1e-4`, `rho = 1.1`, `tol = 1e-5`, 500 iterations), primal tolerance `1e-6`.

| Method | ACC | NMI | PUR | reported ACC |
|---|---|---|---|---|
| FTLRR | 0.8849 ± 0.0169 | 0.9300 ± 0.0075 | 0.8987 ± 0.0146 | 0.8686 |
| NFTLRR | 0.8805 ± 0.0232 | 0.9232 ± 0.0090 | 0.8933 ± 0.0151 | 0.8802 |

The closest factorized baseline reported in the paper, TLRR-TF, obtains 0.8648 on the same
benchmark. Running the dictionary construction once takes about 110 s and each fit about
95 s on a 16-core desktop; the solver converges in roughly 195 iterations.

## Requirements

- MATLAB R2019a or newer (`matchpairs` is used for the accuracy score).
- No toolbox is required: the clustering, the K-means and the metrics are self-contained.

## Quick start

```matlab
addpath('src'); addpath('examples');
demo_synthetic                     % self-contained smoke test, no data needed

addpath(pwd);
run_face('eyaleb', 28, 10)         % needs data/extendyaleb.mat
run_face('frdue', 1, 10)           % needs data/frdue.mat
```

`run_face` builds the dictionary once, runs the solver for both models, performs ten
independent clustering runs and prints mean ± standard deviation of ACC, NMI and purity.

## Data

The MATLAB files are not redistributed here; place them in `data/`.

| File | Variables | Size | Source |
|---|---|---|---|
| `extendyaleb.mat` | `X` (80×840×60), `label` | 2.7 MB | [TLRR-TF repository](https://github.com/YoungukKwon/TLRR-TF), `TLRR_TF_clustering/data/extendyaleb.mat` |
| `frdue.mat` | `X` (25×3040×22), `label` | 6.8 MB | same repository |
| `frdue100.mat` | `X` (25×1980×22), `label` | 4.4 MB | same repository |

For 8-bit images the runner divides `X` by 255; FRDUE is used as stored. See `data/README.md`.

## Files

| File | Purpose |
|---|---|
| `src/FTLRR_main.m` | FTLRR, NFTLRR and the closed-form clean-model solution |
| `src/NFTLRR_cluster.m` | spectral clustering from the affinity, self-contained K-means |
| `src/dictionary_learning.m`, `src/trpca_tnn.m`, `src/prox_tnn.m` | TRPCA dictionary construction |
| `src/tSVDs.m`, `src/tprod.m`, `src/tran.m` | t-SVD and t-product helpers |
| `run_face.m` | reproduce the face-table results |
| `clustering_metrics.m` | ACC, NMI and purity |
| `examples/demo_synthetic.m` | smoke test on generated data |
| `python/reference_solver.py` | independent Python implementation of the solvers |
| `python/coil.py` | COIL-20 and COIL-100 experiments of Section 6.6 |

## Python reference implementation (Section 6.6)

The diagnostics and the COIL experiments were produced with an independent Python
implementation. It is not a line-by-line port: the stopping rules and the affinity
post-processing differ slightly, so absolute scores are close but not identical to the
MATLAB ones. On the face protocol the two implementations agree on the ordering of the
comparison.

```bash
cd python
pip install -r requirements.txt
python coil.py --dataset coil20     # Table 5
python coil.py --dataset coil100    # Table 6
```

Expected ten-seed ACC: COIL-20, FTLRR 0.6107 and NFTLRR 0.6186; COIL-100, FTLRR 0.6315
and NFTLRR 0.6380. See `python/README.md`.

## Notes

- The solver is deterministic given the dictionary, so the ten runs of the reported protocol
  differ only in the spectral clustering.
- `opts.postprocess` selects the affinity post-processing: `'legacy'` (the SVD/power transform
  used for the reported experiments) or `'direct'` (the affinity exactly as defined in the
  paper).
- The width `m` must not exceed the rank of the dictionary returned by `dictionary_learning`.
- `opts.returnZ` materializes the full `n2 × n2 × n3` coefficient tensor; it is off by default
  for large collections, and the reduced tensor is always available as `info.Zprime`.

## Citation

```bibtex
@article{liang2026ftlrr,
  title   = {Tensor Subspace Clustering via Normalized Factorized Low-Rank Representation},
  author  = {Liang, Rongmei and Wang, Chao},
  journal = {Knowledge-Based Systems},
  year    = {2026},
  note    = {Manuscript KNOSYS-D-26-21897}
}
```

## License

MIT; see `LICENSE`. The datasets keep their own terms.

## 中文说明

本仓库是论文中 FTLRR 与 NFTLRR 两种方法的 MATLAB 参考实现。运行 `run_face('eyaleb', 28, 10)`
即可复现人脸数据表的结果（FTLRR 0.8849、NFTLRR 0.8805），数据文件放到 `data/` 目录，
来源见上表。`examples/demo_synthetic.m` 无需任何数据即可验证代码可运行。

## 中文说明（补充）

仓库包含两部分：MATLAB 包复现 6.1–6.5 的人脸实验（运行 un_face('eyaleb', 28, 10)，结果 FTLRR 0.8849、NFTLRR 0.8805）；Python 包（python/）复现 6.6 节的诊断与 COIL 实验（运行 python coil.py --dataset coil20 或 coil100）。两套代码相互独立，人脸协议上的排序一致，绝对数值因停止准则和后处理不同而略有差异。
