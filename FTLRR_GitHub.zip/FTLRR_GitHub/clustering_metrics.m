function [ACC, NMI, PUR] = clustering_metrics(y_true, y_pred)
%CLUSTERING_METRICS ACC, NMI and purity without any toolbox dependency.
%   y_true and y_pred are vectors of class and cluster identifiers.

y_true = y_true(:); y_pred = y_pred(:);
[~, ~, gt] = unique(y_true);
[~, ~, pr] = unique(y_pred);
n = numel(gt);
C = accumarray([gt pr], 1, [max(gt) max(pr)]);

% ACC with optimal label matching
cost = max(C(:)) - C;
pairs = matchpairs(cost, max(C(:)) * max(size(C)));
if isempty(pairs)
    ACC = 0;
else
    ACC = sum(C(sub2ind(size(C), pairs(:, 1), pairs(:, 2)))) / n;
end

% purity
PUR = sum(max(C, [], 1)) / n;

% NMI with arithmetic normalization
P = C / n;
pi = sum(P, 2); pj = sum(P, 1);
ind = pi * pj;
nz = P > 0;
MI = sum(P(nz) .* log(P(nz) ./ ind(nz)));
Hi = -sum(pi(pi > 0) .* log(pi(pi > 0)));
Hj = -sum(pj(pj > 0) .* log(pj(pj > 0)));
NMI = 2 * MI / (Hi + Hj);
end
