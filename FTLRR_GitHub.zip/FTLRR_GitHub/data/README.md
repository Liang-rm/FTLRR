# Data

The MATLAB files are not redistributed with this repository. Download them from the
TLRR-TF repository and place them in this folder:

| File | Variables | Size |
|---|---|---|
| `extendyaleb.mat` | `X` (80×840×60 `uint8`), `label` (840×1) | 2.7 MB |
| `frdue.mat` | `X` (25×3040×22 `double`), `label` (3040×1) | 6.8 MB |
| `frdue100.mat` | `X` (25×1980×22 `double`), `label` (1980×1) | 4.4 MB |

Source: <https://github.com/YoungukKwon/TLRR-TF>, folder `TLRR_TF_clustering/data`.
The EYaleB subset is the one distributed with that repository (28 subjects × 30 images).
Use of the data is subject to the terms of the original providers.

For 8-bit intensities, `run_face` divides `X` by 255; FRDUE is used as stored.

## COIL archives (Python package)

The COIL experiments of Section 6.6 read the original archives from this folder:

| File | Source |
|---|---|
| coil-20-proc.zip | <https://www.cs.columbia.edu/CAVE/databases/SLAM_coil-20_coil-100/coil-20/coil-20-proc.zip> |
| coil-100.zip | <https://www.cs.columbia.edu/CAVE/databases/SLAM_coil-20_coil-100/coil-100/coil-100.zip> |
