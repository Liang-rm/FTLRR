function demo_synthetic()
%DEMO_SYNTHETIC Small, self-contained smoke test of FTLRR and NFTLRR.
repo = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(repo,'src'));
rng(7);
n1=8; n3=4; perClass=8; K=2;
B1=randn(n1,2,n3); B2=randn(n1,2,n3);
X=cat(2,tprod(B1,randn(2,perClass,n3)), ...
    tprod(B2,randn(2,perClass,n3)));
X=X/max(abs(X(:)));

dictOpts=struct('denoising_flag',1, ...
    'lambda',1/sqrt(max(size(X,1),size(X,2))*size(X,3)), ...
    'mu',1e-4,'rho',1.2,'tol',1e-6,'max_iter',100,'DEBUG',0);
[Aprime,V]=dictionary_learning(X,dictOpts);
m=min(2,size(Aprime,2));
opts=struct('Aprime',Aprime,'V',V,'lambda1',0.01, ...
    'lambda2',0.01,'max_iter',100,'tol',1e-5, ...
    'nClusters',K,'postprocess','direct','cluster_runs',1, ...
    'returnZ',false);

opts.model='ftlrr';
[~,Wf,fi]=FTLRR_main(X,m,opts);
opts.model='nftlrr';
[~,Wn,ni]=FTLRR_main(X,m,opts);
assert(all(isfinite(Wf(:))) && all(isfinite(Wn(:))));
assert(numel(fi.labels)==size(X,2) && numel(ni.labels)==size(X,2));
fprintf('FTLRR: %d iterations, %d clusters\n', ...
    fi.iterations,numel(unique(fi.labels)));
fprintf('NFTLRR: %d iterations, %d clusters\n', ...
    ni.iterations,numel(unique(ni.labels)));
end
