# Python reference implementation (Section 6.6)

This folder contains the independent Python implementation used for the numerical
diagnostics and additional experiments of Section 6.6 of the paper. It is separate from
the MATLAB package in the repository root, which produces the face-table results of
Sections 6.1–6.5.

| File | Purpose |
|---|---|
| `reference_solver.py` | TRPCA dictionary, augmented basis, FTLRR/NFTLRR solvers, TNN control, affinity and clustering scores |
| `coil.py` | COIL-20 and COIL-100 experiments of Section 6.6.2–6.6.3 |

## Requirements

```
pip install -r requirements.txt
```

Python 3.12 with NumPy 2.3.5 and SciPy 1.18.1 was used for the reported runs.

## Data

Place the COIL archives in `../data/` (or pass `--data`):

| File | Source |
|---|---|
| `coil-20-proc.zip` | https://www.cs.columbia.edu/CAVE/databases/SLAM_coil-20_coil-100/coil-20/coil-20-proc.zip |
| `coil-100.zip` | https://www.cs.columbia.edu/CAVE/databases/SLAM_coil-20_coil-100/coil-100/coil-100.zip |

## Reproducing Tables 5 and 6

```bash
python coil.py --dataset coil20    # 72 views per object, 20 classes
python coil.py --dataset coil100   # 10 views per object, 100 classes
```

Ten seeds are used by default. Expected means (ACC):

| Dataset | FTLRR | NFTLRR |
|---|---|---|
| COIL-20 | 0.6107 | 0.6186 |
| COIL-100 | 0.6315 | 0.6380 |

The script writes per-run records to `results/` and caches the prepared tensors and the
TRPCA dictionary in `cache/`. Add `--no-tnn` to skip the untuned tensor nuclear norm
control.

## Relationship to the MATLAB package

The two implementations are written independently. The Python solver is used for the
diagnostics and for the second image collection, and it reaches the same ordering of the
face comparison as the MATLAB code; absolute scores differ slightly because the stopping
rules and the affinity post-processing are not identical.
