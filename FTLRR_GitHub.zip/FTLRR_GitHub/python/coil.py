﻿"""COIL-20 and COIL-100 experiments of Section 6.6.

Both collections are reduced to 16 x 16 grayscale, each sample is normalized to unit
Frobenius norm, and the width is m = 8.  The script reports ten-seed means of ACC, NMI
and purity for FTLRR, NFTLRR and (optionally) the untuned TNN control.

Expected results with ten seeds:
    COIL-20  (72 views per object, 1440 samples, 20 classes): FTLRR 0.6107, NFTLRR 0.6186
    COIL-100 (10 views per object, 1000 samples, 100 classes): FTLRR 0.6315, NFTLRR 0.6380

Example
-------
    python coil.py --dataset coil100 --data ../data/coil-100.zip
"""
import argparse
import io
import json
import time
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image

from reference_solver import trpca, augmented_basis, factor_solver, tnn_solver, affinity, score_graph

DATASETS = {
    "coil20": {"per_class": 72, "side": 16, "m": 8},
    "coil100": {"per_class": 10, "side": 16, "m": 8},
}


def load_coil(zip_path, per_class, side, cache_dir):
    """Read the first ``per_class`` views of every object as a 3-D tensor."""
    prepared = cache_dir / f"{zip_path.stem}_{per_class}_{side}.npz"
    if prepared.exists():
        data = np.load(prepared)
        return data["x"], data["y"]

    images, labels = [], []
    with zipfile.ZipFile(zip_path) as zf:
        entries = []
        for info in zf.infolist():
            name = Path(info.filename).name
            if name.lower().endswith(".png") and name.startswith("obj"):
                obj, angle = name[:-4].split("__")
                entries.append((int(obj[3:]), int(angle), info.filename))
        entries.sort()
        by_class = {}
        for obj, angle, name in entries:
            by_class.setdefault(obj, []).append((angle, name))
        for obj in sorted(by_class):
            for _, name in sorted(by_class[obj])[:per_class]:
                image = Image.open(io.BytesIO(zf.read(name))).convert("L")
                image = image.resize((side, side), Image.Resampling.BILINEAR)
                images.append(np.asarray(image, dtype=float) / 255.0)
                labels.append(obj - 1)

    x = np.stack(images, axis=1)
    y = np.asarray(labels)
    x /= np.maximum(np.linalg.norm(x, axis=(0, 2)), 1e-300)[None, :, None]
    np.savez_compressed(prepared, x=x, y=y)
    return x, y


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", choices=sorted(DATASETS), default="coil100")
    parser.add_argument("--data", type=Path, default=None, help="path to the COIL zip")
    parser.add_argument("--seeds", type=int, default=10)
    parser.add_argument("--no-tnn", action="store_true", help="skip the TNN control")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    cache = root / "cache"
    cache.mkdir(exist_ok=True)
    results_dir = root / "results"
    results_dir.mkdir(exist_ok=True)

    spec = DATASETS[args.dataset]
    default_zip = {"coil20": "coil-20-proc.zip", "coil100": "coil-100.zip"}[args.dataset]
    zip_path = args.data if args.data is not None else root.parent / "data" / default_zip
    x, y = load_coil(Path(zip_path), spec["per_class"], spec["side"], cache)
    print(f"{args.dataset}: tensor {x.shape}, {len(np.unique(y))} classes", flush=True)

    dictionary_file = cache / f"{args.dataset}_dictionary.npz"
    meta_file = cache / f"{args.dataset}_trpca.json"
    if dictionary_file.exists() and meta_file.exists():
        basis = augmented_basis(np.load(dictionary_file)["a"])
        prep = json.loads(meta_file.read_text(encoding="utf8"))
    else:
        tic = time.perf_counter()
        a, prep = trpca(x)
        basis = augmented_basis(a)
        np.savez_compressed(dictionary_file, a=a)
        meta_file.write_text(json.dumps(prep), encoding="utf8")
        print(f"trpca {prep['seconds']:.1f} s", flush=True)

    methods = [("FTLRR", lambda: factor_solver(x, basis, spec["m"], seed, normalized=False)),
               ("NFTLRR", lambda: factor_solver(x, basis, spec["m"], seed, normalized=True))]
    if not args.no_tnn:
        methods.append(("TNN-control", lambda: tnn_solver(x, basis, seed)))

    records = []
    for seed in range(args.seeds):
        for name, run in methods:
            z, info = run()
            scores, _ = score_graph(affinity(basis["w"], z, x.shape[2]), y, seed)
            record = {"method": name, "seed": seed,
                      "ACC": float(scores["ACC"]), "NMI": float(scores["NMI"]),
                      "PUR": float(scores["PUR"]), "iterations": int(info["iterations"]),
                      "seconds": float(info["solver_seconds"])}
            records.append(record)
            print(json.dumps(record), flush=True)

    out = results_dir / f"{args.dataset}.json"
    out.write_text(json.dumps(records, indent=1), encoding="utf8")
    for name, _ in methods:
        rows = [r for r in records if r["method"] == name]
        acc = np.array([r["ACC"] for r in rows])
        print(f"{name}: ACC {acc.mean():.4f}+-{acc.std(ddof=1):.4f} "
              f"NMI {np.mean([r['NMI'] for r in rows]):.4f} "
              f"PUR {np.mean([r['PUR'] for r in rows]):.4f}")
    print("saved", out)


if __name__ == "__main__":
    main()