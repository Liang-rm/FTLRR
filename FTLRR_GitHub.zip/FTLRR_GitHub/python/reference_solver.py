"""Independent reference implementation of the manuscript's exact reduced models.

This is newly written code. It does not reconstruct unavailable historical runs.
Array convention: spatial tensors (features, samples, tubes); Fourier arrays
(independent real-FFT frequencies, rows, columns). FFT normalization is NumPy's
unnormalized forward / 1/n3 inverse convention.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import sys, time
from pathlib import Path
if (Path(__file__).parent/'vendor').is_dir():
    sys.path.insert(0,str(Path(__file__).parent/'vendor'))
import numpy as np
from scipy.linalg import qr
from scipy.optimize import linear_sum_assignment
from scipy.sparse.linalg import eigsh
from threadpoolctl import threadpool_limits
threadpool_limits(limits=1)

def fft(x): return np.moveaxis(np.fft.rfft(x,axis=2),2,0)
def ifft(f,n3): return np.fft.irfft(np.moveaxis(f,0,2),n=n3,axis=2)
def adj(x): return x.conj().swapaxes(-1,-2)
def normf(x,n3):
    w=np.full(x.shape[0],2.);w[0]=1
    if n3%2==0:w[-1]=1
    return float(np.sqrt(np.sum(w[:,None,None]*abs(x)**2)/n3))
def opnorm(x):
    gram=x@adj(x)
    return float(np.sqrt(max(0.,np.linalg.eigvalsh(gram).real.max())))
def soft(x,t): return np.sign(x)*np.maximum(abs(x)-t,0.)
def group_soft(x,t):
    n=np.linalg.norm(x,axis=(0,2))
    return x*np.maximum(1-t/np.maximum(n,1e-300),0)[None,:,None]

def synthetic(seed,p=24,n_each=40,n3=8,c=3,d=3):
    rng=np.random.default_rng(seed)
    q=n3//2+1;n=n_each*c
    cf=fft(rng.standard_normal((d,n,n3)))
    lf=np.empty((q,p,n),complex)
    for k in range(q):
        raw=rng.standard_normal((p,c*d))
        if k!=0 and not(n3%2==0 and k==q-1):raw=raw+1j*rng.standard_normal(raw.shape)
        basis=np.linalg.qr(raw,mode='reduced')[0]
        for j in range(c):
            ix=slice(j*n_each,(j+1)*n_each)
            lf[k,:,ix]=basis[:,j*d:(j+1)*d]@cf[k,:,ix]
    clean=ifft(lf,n3)
    clean/=np.linalg.norm(clean,axis=(0,2))[None,:,None]
    x=clean.copy();mask=rng.random(x.shape)<.10
    replacement=rng.uniform(-2.5*abs(clean).max(),2.5*abs(clean).max(),x.shape)
    x[mask]=replacement[mask]
    ix=rng.choice(n,size=int(.10*n),replace=False)
    x[:,ix,:]+=rng.normal(0,.10,(p,len(ix),n3))
    return x,np.repeat(np.arange(c),n_each),clean

def trpca(x,tol=1e-6,cap=250):
    start=time.perf_counter();p,n,n3=x.shape;xf=fft(x)
    lam=1/np.sqrt(max(p,n)*n3)
    mu=1/max(np.linalg.svd(xf[0],compute_uv=False)[0],1e-12)
    sparse=np.zeros_like(x);y=np.zeros_like(x);history=[]
    denom=max(1.,float(np.linalg.norm(x)))
    for it in range(1,cap+1):
        arg=fft(x-sparse+y/mu)
        u,s,vh=np.linalg.svd(arg,full_matrices=False)
        af=(u*np.maximum(s-1/mu,0)[:,None,:])@vh
        a=ifft(af,n3)
        sparse=soft(x-a+y/mu,lam/mu)
        r=x-a-sparse
        rel=float(np.linalg.norm(r))/denom
        history.append([it,mu,rel])
        y+=mu*r
        if rel<=tol:break
        mu=min(1.2*mu,1e6)
    return a,{'seconds':time.perf_counter()-start,'iterations':it,
              'converged':bool(rel<=tol),'relative_reconstruction':rel,
              'lambda':lam,'trajectory':history}

def augmented_basis(a):
    n3=a.shape[2];af=fft(a);q,p,n=af.shape
    gf=np.ones((q,1,n),complex)
    bf=np.concatenate((af,gf),axis=1)
    u,sv,vh=np.linalg.svd(bf,full_matrices=False)
    thresholds=np.finfo(float).eps*max(p+1,n)*sv[:,0]
    ranks=(sv>thresholds[:,None]).sum(axis=1)
    s=max(1,int(ranks.max()))
    w=adj(vh[:,:s,:]);ap=af@w;g1=gf@w
    return {'w':w,'a':ap,'g1':g1,'g2':gf,'s':s,'ranks':ranks,
            'basis_thresholds':thresholds,'af':af,
            'basis_reconstruction_error':normf(af-ap@adj(w),n3),
            'basis_affine_error':normf(gf-g1@adj(w),n3)}

def range_qr(h):
    q,s,m=h.shape;out=np.zeros_like(h);ranks=[];thresholds=[]
    for k in range(q):
        qq,rr,perm=qr(h[k],mode='economic',pivoting=True,check_finite=False)
        diag=abs(np.diag(rr));threshold=np.finfo(float).eps*max(s,m)*(diag.max() if diag.size else 0.)
        rank=int((diag>threshold).sum())
        out[k,:,:rank]=qq[:,:rank];ranks.append(rank);thresholds.append(threshold)
    return out,ranks,thresholds

def _error_distances(e,n,y,lam1,lam2):
    # Exact distances for the two convex subdifferentials at the stored primal variables.
    de=np.where(e!=0,lam1*np.sign(e)-y,np.sign(y)*np.maximum(abs(y)-lam1,0))
    nn=np.linalg.norm(n,axis=(0,2));yn=np.linalg.norm(y,axis=(0,2))
    dn=np.zeros_like(n)
    pos=nn>0
    dn[:,pos,:]=lam2*n[:,pos,:]/nn[pos][None,:,None]-y[:,pos,:]
    dn[:,~pos,:]=y[:,~pos,:]*np.maximum(1-lam2/np.maximum(yn[~pos],1e-300),0)[None,:,None]
    return float(np.linalg.norm(de)),float(np.linalg.norm(dn))

def factor_solver(x,basis,m,seed,normalized=False,lam1=.01,lam2=.01,
                  mu0=.1,rho=1.1,mumax=100.,tol=1e-3,cap=500,
                  checkpoint_iterations=(100,250,500,750,1000)):
    start=time.perf_counter();p,n,n3=x.shape;xf=fft(x)
    a,w,g1,g2=(basis[k] for k in ['a','w','g1','g2'])
    q,s,_=adj(w).shape
    if m>s:raise ValueError(f'm={m} exceeds reduced width s={s}')
    ah=adj(a);gh=adj(g1)
    gram=ah@a+(gh@g1 if normalized else 0)
    eig,vec=np.linalg.eigh(gram)
    eig=np.maximum(eig.real,0)
    aop=opnorm(a);xden=max(1.,float(np.linalg.norm(x)));gden=max(1.,np.sqrt(n))
    rng=np.random.default_rng(100000+seed)
    r=fft(rng.standard_normal((m,n,n3)))
    z=np.zeros((q,s,n),complex);l=np.zeros((q,s,m),complex);prod=z.copy()
    e=np.zeros_like(x);nn=np.zeros_like(x);y=np.zeros_like(x)
    ef=fft(e);nf=fft(nn);yf=fft(y);y2=np.zeros_like(g2)
    history=[];checkpoints={};mu=mu0;timing={k:0. for k in ['coefficient','factor','errors','diagnostics']}
    for it in range(1,cap+1):
        oldz=z;olde=e;oldn=nn;oldprod=prod;oldr=r
        tic=time.perf_counter()
        rhs=prod+mu*(ah@(xf-ef-nf+yf/mu))
        if normalized:rhs+=mu*(gh@(g2-y2/mu))
        z=vec@((adj(vec)@rhs)/(1+mu*eig)[:,:,None])
        timing['coefficient']+=time.perf_counter()-tic
        tic=time.perf_counter()
        l,ranks,rank_tol=range_qr(z@adj(oldr))
        r=adj(l)@z;prod=l@r;d=z-prod
        timing['factor']+=time.perf_counter()-tic
        tic=time.perf_counter()
        azf=a@z;az=ifft(azf,n3)
        e=soft(x-az-oldn+y/mu,lam1/mu)
        nn=group_soft(x-az-e+y/mu,lam2/mu)
        ef=fft(e);nf=fft(nn)
        r1=x-az-e-nn;r1f=xf-azf-ef-nf
        r2=g1@z-g2 if normalized else np.zeros_like(g2)
        y=y+mu*r1;yf=fft(y)
        if normalized:y2=y2+mu*r2
        timing['errors']+=time.perf_counter()-tic
        tic=time.perf_counter()
        dz=normf(z-oldz,n3);dp=normf(prod-oldprod,n3)
        de=float(np.linalg.norm(e-olde));dn=float(np.linalg.norm(nn-oldn))
        recon=float(np.linalg.norm(r1));aff=normf(r2,n3)
        changes={'change_Z':dz/max(1.,normf(oldz,n3)),
                 'change_E':de/max(1.,float(np.linalg.norm(olde))),
                 'change_N':dn/max(1.,float(np.linalg.norm(oldn))),
                 'change_P':dp/max(1.,normf(oldprod,n3))}
        stopping=max(recon/xden,aff/gden,*changes.values())
        gz=d-ah@yf+(gh@y2 if normalized else 0)
        gl=-d@adj(r);gr=-adj(l)@d
        gzn=normf(gz,n3);gln=normf(gl,n3);grn=normf(gr,n3)
        gen,gnn=_error_distances(e,nn,y,lam1,lam2)
        cdef=normf(d@adj(oldr),n3)
        dop=opnorm(d)
        bound=max(recon,aff,dp+mu*aop*(de+dn),dop*dp+cdef,mu*dn)
        selected=max(recon,aff,gzn,gln,grn,mu*dn)
        kkt=max(recon,aff,gzn,gln,grn,gen,gnn)
        obj=.5*normf(d,n3)**2+lam1*abs(e).sum()+lam2*np.linalg.norm(nn,axis=(0,2)).sum()
        record={'iteration':it,'mu':mu,'objective':float(obj),'reconstruction_abs':recon,
          'affine_abs':aff,'reconstruction_rel':recon/xden,'affine_rel':aff/gden,
          **changes,'stopping_value':stopping,'KKT_Z':gzn,'KKT_L':gln,'KKT_R':grn,
          'KKT_E_distance':gen,'KKT_N_distance':gnn,'KKT_residual_exact_blocks':kkt,
          'selected_subgradient_residual':selected,'theorem_bound':bound,
          'projection_defect_c':cdef,'delta_P_abs':dp,'delta_E_abs':de,'delta_N_abs':dn,
          'D_operator_norm':dop,'retained_rank_min':min(ranks),'retained_rank_max':max(ranks),
          'rank_tolerance_max':max(rank_tol),'elapsed':time.perf_counter()-start}
        history.append(record)
        timing['diagnostics']+=time.perf_counter()-tic
        if it in checkpoint_iterations:checkpoints[it]=z.copy()
        if stopping<=tol:break
        mu=min(rho*mu,mumax)
    elapsed=time.perf_counter()-start
    return z,{'method':'NFTLRR' if normalized else 'FTLRR','seed':seed,'m':m,
      'iterations':it,'converged':bool(stopping<=tol),'solver_seconds':elapsed,
      'timing':timing,'history':history,'final':history[-1],'checkpoints':checkpoints,
      'normalization':{'X_denominator':xden,'G_denominator':gden,
      'change_denominator':'max(1, Frobenius norm of the preceding iterate)'},
      'config':{'lambda1':lam1,'lambda2':lam2,'mu0':mu0,'rho':rho,'mumax':mumax,'tol':tol,'cap':cap}}

def tnn_solver(x,basis,seed,lam1=.01,lam2=.01,mu0=.1,rho=1.1,mumax=100.,tol=1e-3,cap=500):
    start=time.perf_counter();p,n,n3=x.shape;xf=fft(x);a=basis['a'];ah=adj(a)
    q,s,_=ah.shape;gram=ah@a
    eig,vec=np.linalg.eigh(gram);eig=np.maximum(eig.real,0)
    z=np.zeros((q,s,n),complex);j=z.copy();y3=z.copy()
    e=np.zeros_like(x);nn=e.copy();y=e.copy();ef=fft(e);nf=fft(nn);yf=fft(y)
    xden=max(1.,float(np.linalg.norm(x)));history=[];mu=mu0
    timing={k:0. for k in ['coefficient','factor','errors','diagnostics']}
    for it in range(1,cap+1):
        oldz=z;oldj=j;olde=e;oldn=nn
        tic=time.perf_counter()
        rhs=j-y3/mu+ah@(xf-ef-nf+yf/mu)
        z=vec@((adj(vec)@rhs)/(1+eig)[:,:,None])
        timing['coefficient']+=time.perf_counter()-tic
        tic=time.perf_counter()
        u,sv,vh=np.linalg.svd(z+y3/mu,full_matrices=False)
        j=(u*np.maximum(sv-1/mu,0)[:,None,:])@vh
        timing['factor']+=time.perf_counter()-tic
        tic=time.perf_counter();azf=a@z;az=ifft(azf,n3)
        e=soft(x-az-oldn+y/mu,lam1/mu);nn=group_soft(x-az-e+y/mu,lam2/mu)
        ef=fft(e);nf=fft(nn);r1=x-az-e-nn;split=z-j
        y=y+mu*r1;yf=fft(y);y3=y3+mu*split
        timing['errors']+=time.perf_counter()-tic
        tic=time.perf_counter()
        changes={'change_Z':normf(z-oldz,n3)/max(1.,normf(oldz,n3)),
                 'change_J':normf(j-oldj,n3)/max(1.,normf(oldj,n3)),
                 'change_E':float(np.linalg.norm(e-olde))/max(1.,float(np.linalg.norm(olde))),
                 'change_N':float(np.linalg.norm(nn-oldn))/max(1.,float(np.linalg.norm(oldn)))}
        recon=float(np.linalg.norm(r1));splitabs=normf(split,n3)
        stopping=max(recon/xden,splitabs/max(1.,normf(z,n3)),*changes.values())
        # Reduced and lifted tensors have equal nonzero singular values slice-wise.
        wts=np.full(q,2.);wts[0]=1
        if n3%2==0:wts[-1]=1
        nuc=float(np.sum(wts[:,None]*np.linalg.svd(j,compute_uv=False))/n3)
        obj=nuc+lam1*abs(e).sum()+lam2*np.linalg.norm(nn,axis=(0,2)).sum()
        history.append({'iteration':it,'mu':mu,'objective':float(obj),'reconstruction_abs':recon,
           'reconstruction_rel':recon/xden,'split_abs':splitabs,
           'split_rel':splitabs/max(1.,normf(z,n3)),**changes,'stopping_value':stopping,
           'elapsed':time.perf_counter()-start})
        timing['diagnostics']+=time.perf_counter()-tic
        if stopping<=tol:break
        mu=min(rho*mu,mumax)
    return z,{'method':'TNN-control','seed':seed,'m':None,'iterations':it,'converged':bool(stopping<=tol),
      'solver_seconds':time.perf_counter()-start,'timing':timing,'history':history,'final':history[-1],
      'config':{'lambda1':lam1,'lambda2':lam2,'mu0':mu0,'rho':rho,'mumax':mumax,'tol':tol,'cap':cap}}

def affinity(w,z,n3,block=128):
    n=w.shape[1];out=np.empty((n,n))
    for start in range(0,n,block):
        coef=ifft(w[:,start:start+block,:]@z,n3)
        out[start:start+block,:]=abs(coef).mean(axis=2)
    out=(out+out.T)/2
    np.fill_diagonal(out,0)
    return out

def _kmeans(v,c,seed,restarts=20):
    rng=np.random.default_rng(seed);best=None;best_cost=np.inf;n=len(v)
    for restart in range(restarts):
        centers=[v[rng.integers(n)]]
        dist=np.sum((v-centers[0])**2,axis=1)
        for _ in range(1,c):
            ix=rng.choice(n,p=dist/dist.sum()) if dist.sum()>0 else rng.integers(n)
            centers.append(v[ix]);dist=np.minimum(dist,np.sum((v-v[ix])**2,axis=1))
        cent=np.array(centers);labels=np.zeros(n,int)
        for it in range(300):
            d=np.maximum(np.sum(v*v,axis=1)[:,None]+np.sum(cent*cent,axis=1)[None,:]-2*v@cent.T,0)
            new=d.argmin(axis=1)
            if it and np.array_equal(new,labels):break
            labels=new
            for k in range(c):
                members=v[labels==k]
                cent[k]=members.mean(axis=0) if len(members) else v[np.argmax(d.min(axis=1))]
        cost=float(np.sum((v-cent[labels])**2))
        if cost<best_cost:best_cost=cost;best=labels.copy()
    return best

def score_graph(graph,truth,seed):
    c=len(np.unique(truth));degree=graph.sum(axis=1)
    scale=1/np.sqrt(np.maximum(degree,1e-300));a=graph*scale[:,None]*scale[None,:]
    vals,v=eigsh(a,k=c,which='LA',tol=1e-8,v0=np.random.default_rng(seed).normal(size=len(a)),maxiter=20000)
    v=v[:,np.argsort(vals)[::-1]]
    v/=np.maximum(np.linalg.norm(v,axis=1,keepdims=True),1e-300)
    pred=_kmeans(v,c,seed)
    classes,yy=np.unique(truth,return_inverse=True);pp=np.unique(pred,return_inverse=True)[1]
    contingency=np.zeros((c,c),int);np.add.at(contingency,(yy,pp),1)
    rr,cc=linear_sum_assignment(-contingency)
    acc=float(contingency[rr,cc].sum()/len(yy));pur=float(contingency.max(axis=0).sum()/len(yy))
    pij=contingency/len(yy);py=pij.sum(axis=1);pprob=pij.sum(axis=0);nz=pij>0
    independent=py[:,None]*pprob[None,:]
    mi=float(np.sum(pij[nz]*np.log(pij[nz]/independent[nz])))
    hy=-float(np.sum(py[py>0]*np.log(py[py>0])));hp=-float(np.sum(pprob[pprob>0]*np.log(pprob[pprob>0])))
    nmi=2*mi/(hy+hp) if hy+hp>0 else 1.
    return {'ACC':acc,'NMI':nmi,'PUR':pur},pred

def evaluate(x,truth,basis,z,info,preprocess_seconds=0.,setup_seconds=0.):
    tic=time.perf_counter();graph=affinity(basis['w'],z,x.shape[2]);scores,pred=score_graph(graph,truth,info['seed'])
    gt=time.perf_counter()-tic
    info.update(scores);info['graph_seconds']=gt;info['preprocess_seconds']=preprocess_seconds
    info['setup_seconds']=setup_seconds;info['total_seconds']=preprocess_seconds+setup_seconds+info['solver_seconds']+gt
    return info,pred,graph
