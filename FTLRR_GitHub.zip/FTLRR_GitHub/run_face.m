﻿function results = run_face(name, m, nRuns, postprocess)
%RUN_FACE Reproduce the face-table results of FTLRR and NFTLRR.
%   results = run_face('eyaleb', 28, 10)
%   results = run_face('frdue', 1, 10)
%
%   The solver is deterministic given the dictionary, so the runs differ only
%   in the spectral clustering, exactly as in the reported ten-run protocol.
%
%   Data files (place them in ./data):
%     eyaleb    extendyaleb.mat   with X (80 x 840 x 60) and label
%     frdue     frdue.mat         with X (25 x 3040 x 22) and label
%     frdue100  frdue100.mat      with X (25 x 1980 x 22) and label
%   They are distributed with the TLRR-TF repository; see data/README.md.

if nargin < 2 || isempty(m), m = 28; end
if nargin < 3 || isempty(nRuns), nRuns = 10; end
if nargin < 4 || isempty(postprocess), postprocess = 'legacy'; end

switch lower(name)
    case 'eyaleb',   file = 'extendyaleb.mat';  scale = 255;
    case 'frdue',    file = 'frdue.mat';        scale = 1;
    case 'frdue100', file = 'frdue100.mat';     scale = 1;
    otherwise, error('name must be eyaleb, frdue or frdue100.');
end

addpath(fullfile(fileparts(mfilename('fullpath')), 'src'));
S = load(fullfile('data', file));
X = S.X;
if scale > 1, X = X / scale; end
label = S.label(:);
[n1, n2, n3] = size(X);
K = numel(unique(label));
fprintf('%s: %d x %d x %d, %d classes, m = %d\n', name, n1, n2, n3, K, m);

dictOpts = struct('denoising_flag', 1, ...
    'lambda', 1 / sqrt(max(n1, n2) * n3), ...
    'mu', 1e-4, 'rho', 1.1, 'tol', 1e-5, 'max_iter', 500, 'DEBUG', 0);
tic; [Aprime, V] = dictionary_learning(X, dictOpts); tDict = toc;

models = {'ftlrr', 'nftlrr'};
results = struct('name', name, 'm', m, 'runs', nRuns, 'models', {{}}, 'time', tDict);
for i = 1:numel(models)
    opts = struct('model', models{i}, 'Aprime', Aprime, 'V', V, ...
        'lambda1', 0.01, 'lambda2', 0.01, 'nClusters', K, ...
        'postprocess', postprocess, 'cluster_runs', 1, ...
        'max_iter', 800, 'tol', 1e-6, 'returnZ', false);
    tic; [~, W, info] = FTLRR_main(X, m, opts); tFit = toc;
    R = zeros(nRuns, 3);
    for run = 1:nRuns
        rng(run);
        labels = NFTLRR_cluster(W, K, opts);
        [acc, nmi, pur] = clustering_metrics(label, labels);
        R(run, :) = [acc nmi pur];
    end
    fprintf('%-7s ACC %.4f +/- %.4f  NMI %.4f +/- %.4f  PUR %.4f +/- %.4f  (%d it, %.1f s)\n', ...
        upper(models{i}), mean(R(:,1)), std(R(:,1)), mean(R(:,2)), std(R(:,2)), ...
        mean(R(:,3)), std(R(:,3)), info.iterations, tFit);
    results.models{end+1} = struct('model', models{i}, 'runs', R, ...
        'iterations', info.iterations, 'fit_seconds', tFit);
end
results.dictionary_seconds = tDict;
end
