function [Z, W, info] = FTLRR_main(X, m, opts)
%FTLRR_MAIN Main solver for the FTLRR / NFTLRR models in the manuscript.
%   [Z,W,INFO] = FTLRR_MAIN(X,M,OPTS)
%   X: real n1-by-n2-by-n3 tensor; samples are lateral slices X(:,j,:).
%   Supply X at the same scale used to learn its dictionary. For 8-bit
%   images, a common choice is X = double(X)/255.
%   M: factorization dimension, 1 <= M <= dictionary tubal rank.
%   OPTS.model: 'nftlrr' (default), 'ftlrr', or 'clean'.
%   OPTS.Aprime and OPTS.V: optional outputs of dictionary_learning(X,...).
%   OPTS.A: optional full denoised dictionary, used if Aprime/V are absent.
%   Otherwise the supplied dictionary_learning.m is called automatically.
%   OPTS.dictionary_options: options for dictionary_learning / trpca_tnn.
%   OPTS.lambda1, lambda2 (default .01), mu (.0001), rho (1.1),
%   max_mu (1e10), tol (1e-6), max_iter (500), verbose (false).
%   OPTS.nClusters: optional number of clusters for spectral clustering.
%   OPTS.postprocess: 'direct' (paper's W), or 'legacy' (SVD/power
%   processing and two normalizations for historical experiments).
%   The default postprocess is 'legacy'; default power is 0.01.
%   OPTS.cluster_runs: number of independent K-means runs (default 1).
%   OPTS.returnZ: whether to materialize n2-by-n2-by-n3 Z. By default,
%   this is false when Z would have more than 20 million elements.
%
%   W follows equation (8) of the manuscript. INFO.Zprime and INFO.V
%   retain the reduced coefficient tensor and dictionary right factor,
%   so Z = tprod(INFO.V, INFO.Zprime) when Z is not materialized.
%
%   Add this repository's src folder to the MATLAB path before calling:
%       addpath('path/to/FTLRR_NFTLRR_GitHub/src')

if nargin < 3 || isempty(opts), opts = struct(); end
validateattributes(X, {'double','single'}, {'real','finite','nonempty'}, mfilename, 'X');
if ndims(X) > 3, error('X must be a third-order tensor.'); end
[n1,n2,n3] = size(X);
validateattributes(m, {'numeric'}, {'scalar','integer','positive'}, mfilename, 'm');
model = lower(char(option(opts,'model','nftlrr')));
if ~ismember(model, {'clean','ftlrr','nftlrr'})
    error('opts.model must be clean, ftlrr, or nftlrr.');
end
returnZ = option(opts,'returnZ',double(n2)*n2*n3 <= 2e7);
blockSize = option(opts,'block_size',32);
validateattributes(blockSize, {'numeric'}, {'scalar','integer','positive'});

if strcmp(model,'clean')
    % Theorem 2 (under its constant Fourier-rank assumption):
    % Z = V_X * V_X^T is a global minimizer for clean X.
    [~,V,~,r] = tSVDs(X);
    if m > r, error('m must not exceed the tubal rank of X (%d).',r); end
    V = real(V);
    Vf = fft(V,[],3);
    Zpf = zeros(r,n2,n3,'like',Vf);
    for k = 1:n3, Zpf(:,:,k) = Vf(:,:,k)'; end
    info = struct('model',model,'iterations',0,'converged',true, ...
        'rank',r,'V',V,'Zprime',real(ifft(Zpf,[],3)), ...
        'factorL',V(:,1:m,:),'factorR',[]);
    info.factorR = real(ifft(permute(conj(Vf(:,1:m,:)),[2 1 3]),[],3));
else
    lambda1 = option(opts,'lambda1',.01);
    lambda2 = option(opts,'lambda2',.01);
    mu = option(opts,'mu',1e-4);
    rho = option(opts,'rho',1.1);
    maxMu = option(opts,'max_mu',1e10);
    tol = option(opts,'tol',1e-6);
    maxIter = option(opts,'max_iter',500);
    verbose = option(opts,'verbose',false);
    validateattributes(lambda1,{'numeric'},{'scalar','nonnegative','finite'});
    validateattributes(lambda2,{'numeric'},{'scalar','nonnegative','finite'});
    validateattributes(mu,{'numeric'},{'scalar','positive','finite'});
    validateattributes(rho,{'numeric'},{'scalar','>=',1,'finite'});
    validateattributes(maxMu,{'numeric'},{'scalar','>=',mu,'finite'});
    validateattributes(tol,{'numeric'},{'scalar','positive','finite'});
    validateattributes(maxIter,{'numeric'},{'scalar','integer','positive'});

    if isfield(opts,'Aprime') && isfield(opts,'V')
        Aprime = opts.Aprime;
        V = opts.V;
    elseif isfield(opts,'A')
        [U,V,S] = tSVDs(opts.A);
        Aprime = tprod(U,S);
    else
        dictOpts = option(opts,'dictionary_options',struct());
        if ~isfield(dictOpts,'denoising_flag'), dictOpts.denoising_flag = 1; end
        if ~isfield(dictOpts,'lambda')
            dictOpts.lambda = 1/sqrt(max(n1,n2)*n3);
        end
        [Aprime,V] = dictionary_learning(X,dictOpts);
    end
    Aprime = real(Aprime);
    V = real(V);
    r = size(Aprime,2);
    if r < 1 || m > r, error('m must be between 1 and dictionary rank %d.',r); end
    if size(Aprime,1) ~= n1 || size(Aprime,3) ~= n3 || ...
            size(V,1) ~= n2 || size(V,2) ~= r || size(V,3) ~= n3
        error('Aprime and V have incompatible sizes.');
    end
    normalized = strcmp(model,'nftlrr');
    Ah = fft(Aprime,[],3);
    Vf = fft(V,[],3);
    Gh = zeros(1,r,n3,'like',Ah);
    if normalized
        % G has ones only in its first frontal slice, so fft(G) is all ones.
        for k = 1:n3
            Gh(:,:,k) = sum(Vf(:,:,k),1);
            if norm(Gh(:,:,k)) <= 1e-12 * max(1,norm(Vf(:,:,k),'fro'))
                error(['Reduced NFTLRR affine constraint is infeasible at ', ...
                    'Fourier slice %d: G*V is zero.'],k);
            end
        end
    end

    % Initialize Z' = V^T; L' is a tensor identity block and R its first
    % m rows. All real tensors are represented by conjugate-symmetric FFTs.
    Zpf = zeros(r,n2,n3,'like',Ah);
    Lf = zeros(r,m,n3,'like',Ah);
    Rf = zeros(m,n2,n3,'like',Ah);
    for k = 1:n3
        Zpf(:,:,k) = Vf(:,:,k)';
        Lf(:,:,k) = eye(r,m);
        Rf(:,:,k) = Zpf(1:m,:,k);
    end
    Zprev = real(ifft(Zpf,[],3));
    E = zeros(size(X),'like',X); N = E; Y1 = E;
    Y2 = zeros(1,n2,n3,'like',X);
    history = zeros(maxIter,2);
    converged = false;

    for iter = 1:maxIter
        Eprev = E; Nprev = N;
        Bh = fft(X-E-N+Y1/mu,[],3);
        if normalized, Y2h = fft(Y2,[],3); end
        half = floor(n3/2)+1;
        for k = 1:half
            Ak = Ah(:,:,k);
            H = eye(r,'like',Ak) + mu*(Ak'*Ak);
            rhs = Lf(:,:,k)*Rf(:,:,k) + mu*(Ak'*Bh(:,:,k));
            if normalized
                gk = Gh(:,:,k);
                H = H + mu*(gk'*gk);
                rhs = rhs + mu*gk'*(ones(1,n2,'like',Ak)-Y2h(:,:,k)/mu);
            end
            Zpf(:,:,k) = H\rhs;
            mirror = n3-k+2;
            if k > 1 && mirror ~= k
                Zpf(:,:,mirror) = conj(Zpf(:,:,k));
            elseif k == 1 || mirror == k
                Zpf(:,:,k) = real(Zpf(:,:,k));
            end
        end

        % Equations (23)-(27): project Z' onto the range of Z'*R_old^T
        % with thin QR, then set L'=Q and R=Q^T*Z'.
        for k = 1:half
            Bk = Zpf(:,:,k)*Rf(:,:,k)';
            [Q,~] = qr(Bk,0);
            mirror = n3-k+2;
            if k == 1 || mirror == k, Q = real(Q); end
            Lf(:,:,k) = Q;
            Rf(:,:,k) = Q'*Zpf(:,:,k);
            if k > 1 && mirror ~= k
                Lf(:,:,mirror) = conj(Lf(:,:,k));
                Rf(:,:,mirror) = conj(Rf(:,:,k));
            end
        end

        Zprime = real(ifft(Zpf,[],3));
        AZh = zeros(n1,n2,n3,'like',Ah);
        for k = 1:n3, AZh(:,:,k) = Ah(:,:,k)*Zpf(:,:,k); end
        AZ = real(ifft(AZh,[],3));
        D = X-AZ-N+Y1/mu;
        E = sign(D).*max(abs(D)-lambda1/mu,0);
        D = X-AZ-E+Y1/mu;
        norms = sqrt(sum(sum(D.^2,1),3));
        weights = max(0,1-(lambda2/mu)./max(norms,eps));
        N = D.*reshape(weights,1,n2,1);

        residual1 = X-AZ-E-N;
        if normalized
            GZh = zeros(1,n2,n3,'like',Ah);
            for k = 1:n3
                GZh(:,:,k) = Gh(:,:,k)*Zpf(:,:,k)-1;
            end
            residual2 = real(ifft(GZh,[],3));
            primal = max(infnorm(residual1),infnorm(residual2));
            Y2 = Y2 + mu*residual2;
        else
            primal = infnorm(residual1);
        end
        change = max([infnorm(Zprime-Zprev), ...
            infnorm(E-Eprev),infnorm(N-Nprev)]);
        history(iter,:) = [primal,change];
        Y1 = Y1 + mu*residual1;
        if verbose && (iter == 1 || mod(iter,10) == 0)
            fprintf('%s iter %d: primal %.3e, change %.3e, mu %.3e\n', ...
                upper(model),iter,primal,change,mu);
        end
        if ~isfinite(primal+change)
            error('FTLRR iteration produced a nonfinite residual.');
        end
        if max(primal,change) <= tol
            converged = true;
            break;
        end
        Zprev = Zprime;
        mu = min(rho*mu,maxMu);
    end
    info = struct('model',model,'iterations',iter,'converged',converged, ...
        'rank',r,'V',V,'Zprime',Zprime, ...
        'factorL',real(ifft(Lf,[],3)), ...
        'factorR',real(ifft(Rf,[],3)), ...
        'residuals',history(1:iter,:),'mu',mu);
end

% Lift coefficients only in blocks. This avoids storing the full Z tensor
% for large face datasets while computing exactly the paper's affinity W.
[Z,W] = lift_affinity(Vf,Zpf,returnZ,blockSize);
if isfield(opts,'nClusters') && ~isempty(opts.nClusters)
    validateattributes(opts.nClusters,{'numeric'}, ...
        {'scalar','integer','positive','<=',n2});
    [info.labels_runs,info.embedding] = NFTLRR_cluster(W,opts.nClusters,opts);
    info.labels = info.labels_runs(:,1);
    info.postprocess = lower(char(option(opts,'postprocess','legacy')));
end
end

function [Z,W] = lift_affinity(Vf,Zpf,returnZ,blockSize)
[n2,~,n3] = size(Vf);
M = zeros(n2,n2);
if returnZ, Z = zeros(n2,n2,n3); else, Z = []; end
for first = 1:blockSize:n2
    rows = first:min(n2,first+blockSize-1);
    ZblockF = zeros(numel(rows),n2,n3,'like',Vf);
    for k = 1:n3
        ZblockF(:,:,k) = Vf(rows,:,k)*Zpf(:,:,k);
    end
    Zblock = real(ifft(ZblockF,[],3));
    M(rows,:) = sum(abs(Zblock),3);
    if returnZ, Z(rows,:,:) = Zblock; end
end
W = (M+M')/(2*n3);
end

function value = option(opts,name,defaultValue)
if isfield(opts,name) && ~isempty(opts.(name))
    value = opts.(name);
else
    value = defaultValue;
end
end

function value = infnorm(A)
value = max(abs(A(:)));
end

