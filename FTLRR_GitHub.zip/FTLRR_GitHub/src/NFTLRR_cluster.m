function [labels_runs, embedding] = NFTLRR_cluster(W, K, opts)
%NFTLRR_CLUSTER Cluster a saved NFTLRR affinity without rerunning the solver.
%   POSTPROCESS='legacy' applies the historical SVD/power transform,
%   including its normalization before spectral clustering.
%   POSTPROCESS='direct' uses the paper's affinity W directly.
%   POSTPROCESS='legacy_single' reproduces the older one-pass output.
if nargin < 3 || isempty(opts), opts = struct(); end
validateattributes(W,{'double','single'},{'real','finite','square','nonempty'});
validateattributes(K,{'numeric'},{'scalar','integer','positive','<=',size(W,1)});
postprocess = lower(char(option(opts,'postprocess','legacy')));
switch postprocess
    case {'legacy','legacy_single'}
        C = legacy_affinity(W,option(opts,'power',0.01));
        if strcmp(postprocess,'legacy')
            C = symmetric_normalize(C);
        end
    case 'direct'
        C = W;
    otherwise
        error('postprocess must be legacy, legacy_single, or direct.');
end
embedding = spectral_embedding(C,K);
runs = option(opts,'cluster_runs',1);
validateattributes(runs,{'numeric'},{'scalar','integer','positive'});
labels_runs = zeros(size(W,1),runs);
for rep=1:runs
    labels_runs(:,rep)=lloyd_kmeans(embedding,K,20,1000);
end
end

function value=option(opts,name,defaultValue)
if isfield(opts,name) && ~isempty(opts.(name))
    value=opts.(name);
else
    value=defaultValue;
end
end

function C=legacy_affinity(W,power)
validateattributes(power,{'numeric'},{'scalar','positive','finite'});
[~,S,U]=svd(W,'econ');
s=diag(S);
if isempty(s) || s(1)<=eps, error('The affinity matrix is zero.'); end
r=sum(s>1e-3*s(1));
B=U(:,1:r)*diag(sqrt(s(1:r)));
B=B./max(sqrt(sum(B.^2,2)),eps);
G=B*B';
C=max(G,0).^power;
C=(C+C')/2;
end

function C=symmetric_normalize(C)
scale=1./sqrt(max(sum(C,2),eps));
C=(scale.*C).*scale';
C=(C+C')/2;
end

function Y=spectral_embedding(W,K)
C=symmetric_normalize(W);
if size(C,1)>=3500 && K<size(C,1)/10
    eigOpts=struct('tol',1e-8,'maxit',1000);
    [U,D]=eigs(C,K,'largestreal',eigOpts);
    [~,order]=sort(real(diag(D)),'descend');
    Y=real(U(:,order));
else
    [U,D]=eig(C,'vector');
    [~,order]=sort(real(D),'descend');
    Y=real(U(:,order(1:K)));
end
Y=Y./max(sqrt(sum(Y.^2,2)),eps);
end

function bestLabels=lloyd_kmeans(Y,K,restarts,maxIter)
n=size(Y,1);
bestLoss=inf;
bestLabels=ones(n,1);
for rep=1:restarts
    C=zeros(K,size(Y,2));
    C(1,:)=Y(randi(n),:);
    nearest=sum((Y-C(1,:)).^2,2);
    for j=2:K
        total=sum(nearest);
        if total<=eps
            idx=randi(n);
        else
            cutoff=rand*total;
            idx=find(cumsum(nearest)>=cutoff,1,'first');
        end
        C(j,:)=Y(idx,:);
        nearest=min(nearest,sum((Y-C(j,:)).^2,2));
    end
    oldLabels=zeros(n,1);
    for iter=1:maxIter
        dist=max(0,sum(Y.^2,2)+sum(C.^2,2)'-2*(Y*C'));
        [~,labels]=min(dist,[],2);
        if isequal(labels,oldLabels), break; end
        oldLabels=labels;
        for j=1:K
            members=(labels==j);
            if any(members)
                C(j,:)=mean(Y(members,:),1);
            else
                [~,idx]=max(min(dist,[],2));
                C(j,:)=Y(idx,:);
                labels(idx)=j;
            end
        end
    end
    loss=sum(sum((Y-C(labels,:)).^2,2));
    if loss<bestLoss
        bestLoss=loss;
        bestLabels=labels;
    end
end
end
