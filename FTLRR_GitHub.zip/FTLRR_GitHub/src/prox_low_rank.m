function [ Y,trank,U,V,S ] = prox_low_rank(Y,tho)
% 通过奇异值分解（SVD）和自适应截断来近似输入的张量
[n1,n2,n3] = size(Y);
n12 = min(n1,n2);
Y = fft(Y,[],3);
U = zeros(n1,n12,n3);
V = zeros(n2,n12,n3);
S = zeros(n12,n12,n3);

trank = 0;
for i = 1 : n3
    
    [U(:,:,i),s,V(:,:,i)] = svd(Y(:,:,i),'econ');
    
    r=rank(Y(:,:,i));
    s = diag(s);
    ss=s(1:r-2)./s(2:r-1); % 相邻奇异值比率
    
    tranki=find(ss>tho); % 找出比率大于阈值的索引,比率大于 tho的位置可能表示重要成分的边界
    if isempty(tranki)
        tranki=r; % 若没有找到明显下降点，则保留全部秩
    else if length(tranki)>1
           tranki=tranki(1); % 若有多个下降点，取第一个。
        end
    end
            
            
    [p,idx]=max(ss);
    ratio=(r-2)*p/(sum(ss)-p); % 计算最大值与其他比率的平均值的比值
    if ratio>50 % 最大比值是其他比值平均值的50倍以上，表明奇异值序列在某个位置发生了极其陡峭的下降
        tranki=min(tranki,idx);
    end
    % 当奇异值下降模式不明显时，依赖第一层阈值
    % 当存在极其明显的断点时，第二层强制在断点处截断
%     idx=find(s>=tho*s(1));
%     r=rank(Y(:,:,i));
%     tranki=min(length(idx),r);
    
    s=s(1:tranki);  
    S(1:tranki,1:tranki,i) = diag(s);
    U(:,1:tranki,i)=U(:,1:tranki,i);
    V(:,1:tranki,i)=V(:,1:tranki,i);
    trank = max(tranki,trank);
end
U = U(:,1:trank,:);
V = V(:,1:trank,:);
S = S(1:trank,1:trank,:);

U = ifft(U,[],3);
S = ifft(S,[],3);
V = ifft(V,[],3);
Y = tprod( tprod(U,S), tran(V));
end

